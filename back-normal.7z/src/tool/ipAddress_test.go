package tool

// import "testing"

// func TestGetOutBoundIp(t *testing.T) {
// 	ip, _ := GetOutBoundIP()
// 	println(ip)
// }
